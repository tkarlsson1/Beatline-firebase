/* firebase-classic.js now consolidated into firebase.js */
export {};
