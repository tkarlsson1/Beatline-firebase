/* Legacy shim: functionality moved to ES modules in assets/js/* */
// Intentionally left minimal to prevent double initialization.
// If something relied on global symbols from script.js, they are now under window.ns.
